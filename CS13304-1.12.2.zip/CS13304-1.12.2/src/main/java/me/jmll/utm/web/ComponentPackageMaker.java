package me.jmll.utm.web;

/**
 * Clase vacía para indentificar el paquete 
 * que lo contiene para utilizar basePackageClasses
 *  en la anotacieón @ComponentScan
 */
public class ComponentPackageMaker {

}
